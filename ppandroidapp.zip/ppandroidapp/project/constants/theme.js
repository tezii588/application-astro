// export const COLORS = {
//   primary: '#FF6F00',
//   secondary: '#FF9800',
//   tertiary: '#FFC107',
  
//   white: '#FFFFFF',
//   black: '#000000',
  
//   darkGray: '#333333',
//   mediumGray: '#666666',
//   lightGray: '#DDDDDD',
  
//   success: '#4CAF50',
//   error: '#F44336',
//   warning: '#FFC107',
  
//   lightBackground: '#F5F5F5',
// };

// export const SIZES = {
//   // Font sizes
//   extraSmall: 10,
//   small: 12,
//   medium: 14,
//   large: 16,
//   extraLarge: 18,
//   heading: 24,
//   title: 20,
  
//   // Spacing
//   spacing: {
//     xs: 4,
//     s: 8,
//     m: 16,
//     l: 24,
//     xl: 32,
//     xxl: 40,
//   },
  
//   // Border radius
//   radius: {
//     xs: 4,
//     s: 8,
//     m: 12,
//     l: 16,
//     xl: 24,
//     xxl: 32,
//   }
// };

// export const FONTS = {
//   regular: 'System',
//   medium: 'System',
//   bold: 'System-Bold',
// };

// theme.js

export const COLORS = {
  // Primary theme colors for astrology + scientific tone
  primary: '#301005',        // Deep orange (main action color)
  secondary: '#F3BD0F',      // Light orange
  tertiary: '#FF8A65',       // Warm coral for subtle highlights

  // Background and surface
  background: '#FFF8F0',     // Soft orange-tinted white (main background)
  surface: '#FFFFFF',        // White for cards, inputs, etc.

  // Gradient colors (useful with LinearGradient)
  gradientStart: '#FF6F00',  // Deep orange
  gradientEnd: '#F44336',    // Vibrant scientific red

  // Standard colors
  white: '#FFFFFF',
  black: '#000000',

  // Grayscale shades
  darkGray: '#3E3E3E',
  mediumGray: '#757575',
  lightGray: '#E0E0E0',

  // Semantic colors
  success: '#4CAF50',        // Green
  error: '#E53935',          // Red
  warning: '#FFC107',        // Yellow

  // Extra
  lightBackground: '#FAF3E0', // Light off-white
};

export const SIZES = {
  // Font sizes
  extraSmall: 10,
  small: 12,
  medium: 14,
  large: 16,
  extraLarge: 18,
  title: 20,
  heading: 24,

  // Spacing
  spacing: {
    xs: 4,
    s: 8,
    m: 16,
    l: 24,
    xl: 32,
    xxl: 40,
  },

  // Border radius
  radius: {
    xs: 4,
    s: 8,
    m: 12,
    l: 16,
    xl: 24,
    xxl: 32,
  }
};

export const FONTS = {
  regular: 'System',
  medium: 'System',
  bold: 'System-Bold',
};
