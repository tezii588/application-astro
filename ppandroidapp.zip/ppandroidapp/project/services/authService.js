export const loginUser = async (email, password, role) => {
  if (!email || !password) {
    throw new Error('Email and password are required');
  }

  // Simulate API request delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  return {
    id: '123',
    name: email.split('@')[0],
    email,
    role,
    token: 'mock-jwt-token-12345'
  };
};

export const registerUser = async (name, email, password, role) => {
  if (!name || !email || !password) {
    throw new Error('Name, email and password are required');
  }

  // Simulate API request delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  return {
    id: '123',
    name,
    email,
    role,
    token: 'mock-jwt-token-12345'
  };
};

export const requestPasswordReset = async (email) => {
  if (!email) {
    throw new Error('Email is required');
  }

  // Simulate API request delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  return { success: true, message: 'Password reset link sent to your email' };
};