import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity 
} from 'react-native';
import { COLORS } from '../../constants/theme';
import { Users, MessageCircle, Phone, DollarSign, Calendar, ChartBar as BarChart2, TrendingUp, ArrowUp, ArrowDown } from 'lucide-react-native';

export default function AdminDashboard() {
  const [statsData, setStatsData] = useState({
    totalUsers: 0,
    totalAstrologers: 0,
    totalChats: 0,
    totalCalls: 0,
    totalRevenue: 0
  });
  
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulating API call to fetch dashboard data
    setTimeout(() => {
      setStatsData({
        totalUsers: 1256,
        totalAstrologers: 32,
        totalChats: 876,
        totalCalls: 345,
        totalRevenue: 124500
      });
      setLoading(false);
    }, 1000);
  }, []);

  // Monthly revenue data for the chart
  const monthlyRevenue = [
    { month: 'Jan', amount: 8000 },
    { month: 'Feb', amount: 12000 },
    { month: 'Mar', amount: 9500 },
    { month: 'Apr', amount: 14000 },
    { month: 'May', amount: 11000 },
    { month: 'Jun', amount: 16500 },
  ];

  // Simple chart renderer
  const renderBarChart = () => {
    const maxAmount = Math.max(...monthlyRevenue.map(item => item.amount));
    
    return (
      <View style={styles.chartContainer}>
        {monthlyRevenue.map((item, index) => {
          const barHeight = (item.amount / maxAmount) * 120;
          return (
            <View key={index} style={styles.barContainer}>
              <View style={[styles.bar, { height: barHeight }]} />
              <Text style={styles.barLabel}>{item.month}</Text>
            </View>
          );
        })}
      </View>
    );
  };

  // Recent activities
  const recentActivities = [
    {
      id: '1',
      type: 'user',
      description: 'New user registered',
      name: 'Rahul Sharma',
      time: '2 hours ago'
    },
    {
      id: '2',
      type: 'chat',
      description: 'New chat consultation',
      name: 'Priya with Acharya Sharma',
      time: '4 hours ago'
    },
    {
      id: '3',
      type: 'call',
      description: 'New call consultation',
      name: 'Vikram with Dr. Priya Verma',
      time: '6 hours ago'
    },
    {
      id: '4',
      type: 'payment',
      description: 'New payment received',
      name: '₹500 from Nisha Patel',
      time: '8 hours ago'
    }
  ];

  const renderActivityIcon = (type) => {
    switch (type) {
      case 'user':
        return <Users size={16} color={COLORS.primary} />;
      case 'chat':
        return <MessageCircle size={16} color={COLORS.primary} />;
      case 'call':
        return <Phone size={16} color={COLORS.primary} />;
      case 'payment':
        return <DollarSign size={16} color={COLORS.primary} />;
      default:
        return <Calendar size={16} color={COLORS.primary} />;
    }
  };

  if (loading) {
    return (
      <View style={[styles.container, styles.centered]}>
        <Text>Loading dashboard data...</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Admin Dashboard</Text>
        <Text style={styles.headerDate}>June 10, 2025</Text>
      </View>

      {/* Stats Cards Row */}
      <View style={styles.statsContainer}>
        <View style={styles.statsCard}>
          <View style={styles.statsIconContainer}>
            <Users size={20} color={COLORS.primary} />
          </View>
          <View style={styles.statsContent}>
            <Text style={styles.statsLabel}>Total Users</Text>
            <Text style={styles.statsValue}>{statsData.totalUsers}</Text>
            <View style={styles.statsTrend}>
              <ArrowUp size={12} color={COLORS.success} />
              <Text style={[styles.statsTrendText, styles.statsTrendPositive]}>+12%</Text>
            </View>
          </View>
        </View>

        <View style={styles.statsCard}>
          <View style={styles.statsIconContainer}>
            <MessageCircle size={20} color={COLORS.primary} />
          </View>
          <View style={styles.statsContent}>
            <Text style={styles.statsLabel}>Total Chats</Text>
            <Text style={styles.statsValue}>{statsData.totalChats}</Text>
            <View style={styles.statsTrend}>
              <ArrowUp size={12} color={COLORS.success} />
              <Text style={[styles.statsTrendText, styles.statsTrendPositive]}>+8%</Text>
            </View>
          </View>
        </View>
      </View>

      <View style={styles.statsContainer}>
        <View style={styles.statsCard}>
          <View style={styles.statsIconContainer}>
            <Phone size={20} color={COLORS.primary} />
          </View>
          <View style={styles.statsContent}>
            <Text style={styles.statsLabel}>Total Calls</Text>
            <Text style={styles.statsValue}>{statsData.totalCalls}</Text>
            <View style={styles.statsTrend}>
              <ArrowUp size={12} color={COLORS.success} />
              <Text style={[styles.statsTrendText, styles.statsTrendPositive]}>+5%</Text>
            </View>
          </View>
        </View>

        <View style={styles.statsCard}>
          <View style={styles.statsIconContainer}>
            <DollarSign size={20} color={COLORS.primary} />
          </View>
          <View style={styles.statsContent}>
            <Text style={styles.statsLabel}>Revenue</Text>
            <Text style={styles.statsValue}>₹{statsData.totalRevenue}</Text>
            <View style={styles.statsTrend}>
              <ArrowDown size={12} color={COLORS.error} />
              <Text style={[styles.statsTrendText, styles.statsTrendNegative]}>-3%</Text>
            </View>
          </View>
        </View>
      </View>

      {/* Revenue Chart */}
      <View style={styles.chartCard}>
        <View style={styles.chartHeader}>
          <Text style={styles.chartTitle}>Revenue Overview</Text>
          <TouchableOpacity style={styles.chartFilter}>
            <Text style={styles.chartFilterText}>Last 6 Months</Text>
          </TouchableOpacity>
        </View>
        {renderBarChart()}
      </View>

      {/* Recent Activity */}
      <View style={styles.activityCard}>
        <View style={styles.activityHeader}>
          <Text style={styles.activityTitle}>Recent Activity</Text>
          <TouchableOpacity>
            <Text style={styles.viewAllText}>View All</Text>
          </TouchableOpacity>
        </View>
        
        {recentActivities.map(activity => (
          <View key={activity.id} style={styles.activityItem}>
            <View style={styles.activityIconContainer}>
              {renderActivityIcon(activity.type)}
            </View>
            <View style={styles.activityInfo}>
              <Text style={styles.activityDescription}>{activity.description}</Text>
              <Text style={styles.activityName}>{activity.name}</Text>
            </View>
            <Text style={styles.activityTime}>{activity.time}</Text>
          </View>
        ))}
      </View>

      {/* Quick Actions */}
      <View style={styles.quickActionsCard}>
        <Text style={styles.quickActionsTitle}>Quick Actions</Text>
        <View style={styles.quickActionsGrid}>
          <TouchableOpacity style={styles.quickActionButton}>
            <Users size={24} color={COLORS.primary} />
            <Text style={styles.quickActionText}>Add User</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.quickActionButton}>
            <Coffee size={24} color={COLORS.primary} />
            <Text style={styles.quickActionText}>Add Astrologer</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.quickActionButton}>
            <BarChart2 size={24} color={COLORS.primary} />
            <Text style={styles.quickActionText}>View Reports</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.quickActionButton}>
            <TrendingUp size={24} color={COLORS.primary} />
            <Text style={styles.quickActionText}>Analytics</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.lightBackground,
  },
  centered: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    padding: 16,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.darkGray,
  },
  headerDate: {
    fontSize: 14,
    color: COLORS.darkGray,
    opacity: 0.7,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  statsCard: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    padding: 16,
    width: '48%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  statsIconContainer: {
    backgroundColor: 'rgba(255, 111, 0, 0.1)',
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  statsContent: {
    flex: 1,
  },
  statsLabel: {
    fontSize: 14,
    color: COLORS.darkGray,
    marginBottom: 4,
  },
  statsValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.darkGray,
  },
  statsTrend: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 4,
  },
  statsTrendText: {
    fontSize: 12,
    marginLeft: 2,
  },
  statsTrendPositive: {
    color: COLORS.success,
  },
  statsTrendNegative: {
    color: COLORS.error,
  },
  chartCard: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    padding: 16,
    margin: 16,
    marginTop: 0,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  chartHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  chartTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.darkGray,
  },
  chartFilter: {
    backgroundColor: 'rgba(255, 111, 0, 0.1)',
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 4,
  },
  chartFilterText: {
    fontSize: 12,
    color: COLORS.primary,
  },
  chartContainer: {
    height: 160,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    paddingTop: 20,
  },
  barContainer: {
    alignItems: 'center',
    flex: 1,
  },
  bar: {
    width: 20,
    backgroundColor: COLORS.primary,
    borderRadius: 4,
    marginBottom: 8,
  },
  barLabel: {
    fontSize: 12,
    color: COLORS.darkGray,
  },
  activityCard: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    padding: 16,
    margin: 16,
    marginTop: 0,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  activityHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  activityTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.darkGray,
  },
  viewAllText: {
    fontSize: 14,
    color: COLORS.primary,
  },
  activityItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.lightGray,
  },
  activityIconContainer: {
    backgroundColor: 'rgba(255, 111, 0, 0.1)',
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  activityInfo: {
    flex: 1,
  },
  activityDescription: {
    fontSize: 14,
    fontWeight: '500',
    color: COLORS.darkGray,
  },
  activityName: {
    fontSize: 12,
    color: COLORS.darkGray,
    opacity: 0.7,
  },
  activityTime: {
    fontSize: 12,
    color: COLORS.darkGray,
    opacity: 0.7,
  },
  quickActionsCard: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    padding: 16,
    margin: 16,
    marginTop: 0,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  quickActionsTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.darkGray,
    marginBottom: 16,
  },
  quickActionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  quickActionButton: {
    width: '48%',
    backgroundColor: 'rgba(255, 111, 0, 0.1)',
    borderRadius: 8,
    padding: 16,
    alignItems: 'center',
    marginBottom: 16,
  },
  quickActionText: {
    fontSize: 14,
    color: COLORS.darkGray,
    fontWeight: '500',
    marginTop: 8,
  },
});