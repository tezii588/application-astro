import React, { useEffect, useState } from 'react';
import { Platform } from 'react-native';
import { Tabs } from 'expo-router';
import { getUserData } from '../../utils/authUtils';
import { COLORS } from '../../constants/theme';
import { Chrome as Home, Users, Coffee, Compass, User } from 'lucide-react-native';

export default function AdminLayout() {
  const [username, setUsername] = useState('Admin');
  
  useEffect(() => {
    let isMounted = true;

    const fetchUserData = async () => {
      try {
        const userData = await getUserData();
        if (isMounted && userData && userData.name) {
          setUsername(userData.name);
        }
      } catch (error) {
        if (isMounted) {
          console.error('Error fetching user data:', error);
        }
      }
    };
    
    fetchUserData();

    return () => {
      isMounted = false;
    };
  }, []);

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: COLORS.primary,
        tabBarInactiveTintColor: COLORS.darkGray,
        tabBarStyle: {
          height: Platform.OS === 'ios' ? 90 : 70,
          paddingBottom: Platform.OS === 'ios' ? 25 : 10,
          paddingTop: 10,
          backgroundColor: COLORS.white,
          borderTopWidth: 1,
          borderTopColor: COLORS.lightGray,
          elevation: 10,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: -2 },
          shadowOpacity: 0.1,
          shadowRadius: 4,
        },
        tabBarLabelStyle: {
          fontSize: 12,
          fontWeight: '500',
        },
        headerStyle: {
          backgroundColor: COLORS.primary,
        },
        headerTintColor: COLORS.white,
        headerTitleStyle: {
          fontWeight: 'bold',
        },
        headerTitleAlign: 'center',
      }}>
      <Tabs.Screen
        name="dashboard"
        options={{
          title: 'Dashboard',
          tabBarIcon: ({ color }) => <Home size={24} color={color} />,
          headerTitle: `Admin Dashboard - ${username}`,
        }}
      />
      <Tabs.Screen
        name="users"
        options={{
          title: 'Users',
          tabBarIcon: ({ color }) => <Users size={24} color={color} />,
          headerTitle: 'Manage Users',
        }}
      />
      <Tabs.Screen
        name="astrologers"
        options={{
          title: 'Astrologers',
          tabBarIcon: ({ color }) => <Coffee size={24} color={color} />,
          headerTitle: 'Manage Astrologers',
        }}
      />
      <Tabs.Screen
        name="remedies"
        options={{
          title: 'Remedies',
          tabBarIcon: ({ color }) => <Compass size={24} color={color} />,
          headerTitle: 'Manage Remedies',
        }}
      />
      <Tabs.Screen
        name="profile"
        options={{
          title: 'Settings',
          tabBarIcon: ({ color }) => <User size={24} color={color} />,
          headerTitle: 'Admin Settings',
        }}
      />
    </Tabs>
  );
}