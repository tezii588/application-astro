import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  FlatList, 
  TouchableOpacity, 
  TextInput,
  Alert,
  Modal
} from 'react-native';
import { COLORS } from '../../constants/theme';
import { Search, Filter, CreditCard as Edit, Trash2, Ban, UserPlus, X, Save } from 'lucide-react-native';

export default function UsersManagement() {
  const [users, setUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [editModalVisible, setEditModalVisible] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [editedUser, setEditedUser] = useState({
    name: '',
    email: '',
    status: '',
    role: ''
  });

  useEffect(() => {
    // Simulating API call to fetch users
    setTimeout(() => {
      const mockUsers = [
        {
          id: '1',
          name: 'Rahul Sharma',
          email: 'rahul.sharma@example.com',
          joinedDate: '2023-05-10',
          lastActive: '2023-06-09',
          status: 'active',
          role: 'user',
          walletBalance: 1250
        },
        {
          id: '2',
          name: 'Priya Patel',
          email: 'priya.patel@example.com',
          joinedDate: '2023-03-15',
          lastActive: '2023-06-10',
          status: 'active',
          role: 'user',
          walletBalance: 850
        },
        {
          id: '3',
          name: 'Vikram Singh',
          email: 'vikram.singh@example.com',
          joinedDate: '2023-01-20',
          lastActive: '2023-05-25',
          status: 'inactive',
          role: 'user',
          walletBalance: 0
        },
        {
          id: '4',
          name: 'Nisha Verma',
          email: 'nisha.verma@example.com',
          joinedDate: '2023-04-05',
          lastActive: '2023-06-08',
          status: 'banned',
          role: 'user',
          walletBalance: 0
        },
        {
          id: '5',
          name: 'Ajay Kumar',
          email: 'ajay.kumar@example.com',
          joinedDate: '2023-02-12',
          lastActive: '2023-06-07',
          status: 'active',
          role: 'admin',
          walletBalance: 0
        },
      ];
      setUsers(mockUsers);
      setFilteredUsers(mockUsers);
      setLoading(false);
    }, 1000);
  }, []);

  useEffect(() => {
    if (searchQuery) {
      const filtered = users.filter(user => 
        user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.email.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setFilteredUsers(filtered);
    } else {
      setFilteredUsers(users);
    }
  }, [searchQuery, users]);

  const handleSearch = (text) => {
    setSearchQuery(text);
  };

  const handleEditUser = (user) => {
    setSelectedUser(user);
    setEditedUser({
      name: user.name,
      email: user.email,
      status: user.status,
      role: user.role
    });
    setEditModalVisible(true);
  };

  const handleSaveUser = () => {
    if (!editedUser.name || !editedUser.email) {
      Alert.alert('Error', 'Name and email are required fields');
      return;
    }

    // Update user in state (in a real app, this would be an API call)
    const updatedUsers = users.map(user => {
      if (user.id === selectedUser.id) {
        return { ...user, ...editedUser };
      }
      return user;
    });

    setUsers(updatedUsers);
    setFilteredUsers(updatedUsers);
    setEditModalVisible(false);
    Alert.alert('Success', 'User updated successfully');
  };

  const handleDeleteUser = (user) => {
    Alert.alert(
      'Delete User',
      `Are you sure you want to delete ${user.name}?`,
      [
        {
          text: 'Cancel',
          style: 'cancel'
        },
        {
          text: 'Delete',
          onPress: () => {
            // Delete user from state (in a real app, this would be an API call)
            const updatedUsers = users.filter(u => u.id !== user.id);
            setUsers(updatedUsers);
            setFilteredUsers(updatedUsers);
            Alert.alert('Success', 'User deleted successfully');
          },
          style: 'destructive'
        }
      ]
    );
  };

  const handleBanUser = (user) => {
    Alert.alert(
      user.status === 'banned' ? 'Unban User' : 'Ban User',
      `Are you sure you want to ${user.status === 'banned' ? 'unban' : 'ban'} ${user.name}?`,
      [
        {
          text: 'Cancel',
          style: 'cancel'
        },
        {
          text: user.status === 'banned' ? 'Unban' : 'Ban',
          onPress: () => {
            // Update user status in state (in a real app, this would be an API call)
            const updatedUsers = users.map(u => {
              if (u.id === user.id) {
                return { ...u, status: u.status === 'banned' ? 'active' : 'banned' };
              }
              return u;
            });
            setUsers(updatedUsers);
            setFilteredUsers(updatedUsers);
            Alert.alert('Success', `User ${user.status === 'banned' ? 'unbanned' : 'banned'} successfully`);
          }
        }
      ]
    );
  };

  const renderUserStatus = (status) => {
    let color;
    switch (status) {
      case 'active':
        color = COLORS.success;
        break;
      case 'inactive':
        color = COLORS.warning;
        break;
      case 'banned':
        color = COLORS.error;
        break;
      default:
        color = COLORS.darkGray;
    }

    return (
      <View style={[styles.statusBadge, { backgroundColor: color }]}>
        <Text style={styles.statusText}>{status.charAt(0).toUpperCase() + status.slice(1)}</Text>
      </View>
    );
  };

  const renderUserItem = ({ item }) => (
    <View style={styles.userCard}>
      <View style={styles.userHeader}>
        <Text style={styles.userName}>{item.name}</Text>
        {renderUserStatus(item.status)}
      </View>
      
      <Text style={styles.userEmail}>{item.email}</Text>
      
      <View style={styles.userDetails}>
        <View style={styles.userDetail}>
          <Text style={styles.detailLabel}>Role:</Text>
          <Text style={styles.detailValue}>{item.role}</Text>
        </View>
        
        <View style={styles.userDetail}>
          <Text style={styles.detailLabel}>Joined:</Text>
          <Text style={styles.detailValue}>{new Date(item.joinedDate).toLocaleDateString()}</Text>
        </View>
        
        <View style={styles.userDetail}>
          <Text style={styles.detailLabel}>Last Active:</Text>
          <Text style={styles.detailValue}>{new Date(item.lastActive).toLocaleDateString()}</Text>
        </View>
        
        {item.role === 'user' && (
          <View style={styles.userDetail}>
            <Text style={styles.detailLabel}>Wallet Balance:</Text>
            <Text style={styles.detailValue}>₹{item.walletBalance}</Text>
          </View>
        )}
      </View>
      
      <View style={styles.userActions}>
        <TouchableOpacity 
          style={styles.actionButton}
          onPress={() => handleEditUser(item)}
        >
          <Edit size={18} color={COLORS.primary} />
          <Text style={styles.actionText}>Edit</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.actionButton}
          onPress={() => handleBanUser(item)}
        >
          <Ban size={18} color={item.status === 'banned' ? COLORS.success : COLORS.warning} />
          <Text style={[styles.actionText, { color: item.status === 'banned' ? COLORS.success : COLORS.warning }]}>
            {item.status === 'banned' ? 'Unban' : 'Ban'}
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.actionButton}
          onPress={() => handleDeleteUser(item)}
        >
          <Trash2 size={18} color={COLORS.error} />
          <Text style={[styles.actionText, { color: COLORS.error }]}>Delete</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  if (loading) {
    return (
      <View style={[styles.container, styles.centered]}>
        <Text>Loading users...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Search Bar */}
      <View style={styles.searchContainer}>
        <View style={styles.searchBar}>
          <Search size={20} color={COLORS.darkGray} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search users..."
            value={searchQuery}
            onChangeText={handleSearch}
          />
        </View>
        <TouchableOpacity style={styles.filterButton}>
          <Filter size={20} color={COLORS.darkGray} />
        </TouchableOpacity>
      </View>

      {/* Users List */}
      <FlatList
        data={filteredUsers}
        renderItem={renderUserItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listContainer}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>No users found</Text>
          </View>
        }
      />

      {/* Add User Button */}
      <TouchableOpacity style={styles.addButton}>
        <UserPlus size={24} color={COLORS.white} />
      </TouchableOpacity>

      {/* Edit User Modal */}
      <Modal
        visible={editModalVisible}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setEditModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Edit User</Text>
              <TouchableOpacity
                onPress={() => setEditModalVisible(false)}
                style={styles.closeButton}
              >
                <X size={24} color={COLORS.darkGray} />
              </TouchableOpacity>
            </View>

            <View style={styles.formContainer}>
              <View style={styles.formGroup}>
                <Text style={styles.formLabel}>Name</Text>
                <TextInput
                  style={styles.formInput}
                  value={editedUser.name}
                  onChangeText={(text) => setEditedUser({...editedUser, name: text})}
                />
              </View>

              <View style={styles.formGroup}>
                <Text style={styles.formLabel}>Email</Text>
                <TextInput
                  style={styles.formInput}
                  value={editedUser.email}
                  onChangeText={(text) => setEditedUser({...editedUser, email: text})}
                  keyboardType="email-address"
                />
              </View>

              <View style={styles.formGroup}>
                <Text style={styles.formLabel}>Status</Text>
                <View style={styles.pickerContainer}>
                  <TouchableOpacity
                    style={[
                      styles.pickerOption,
                      editedUser.status === 'active' && styles.pickerOptionSelected
                    ]}
                    onPress={() => setEditedUser({...editedUser, status: 'active'})}
                  >
                    <Text style={[
                      styles.pickerOptionText,
                      editedUser.status === 'active' && styles.pickerOptionTextSelected
                    ]}>Active</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[
                      styles.pickerOption,
                      editedUser.status === 'inactive' && styles.pickerOptionSelected
                    ]}
                    onPress={() => setEditedUser({...editedUser, status: 'inactive'})}
                  >
                    <Text style={[
                      styles.pickerOptionText,
                      editedUser.status === 'inactive' && styles.pickerOptionTextSelected
                    ]}>Inactive</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[
                      styles.pickerOption,
                      editedUser.status === 'banned' && styles.pickerOptionSelected
                    ]}
                    onPress={() => setEditedUser({...editedUser, status: 'banned'})}
                  >
                    <Text style={[
                      styles.pickerOptionText,
                      editedUser.status === 'banned' && styles.pickerOptionTextSelected
                    ]}>Banned</Text>
                  </TouchableOpacity>
                </View>
              </View>

              <View style={styles.formGroup}>
                <Text style={styles.formLabel}>Role</Text>
                <View style={styles.pickerContainer}>
                  <TouchableOpacity
                    style={[
                      styles.pickerOption,
                      editedUser.role === 'user' && styles.pickerOptionSelected
                    ]}
                    onPress={() => setEditedUser({...editedUser, role: 'user'})}
                  >
                    <Text style={[
                      styles.pickerOptionText,
                      editedUser.role === 'user' && styles.pickerOptionTextSelected
                    ]}>User</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[
                      styles.pickerOption,
                      editedUser.role === 'admin' && styles.pickerOptionSelected
                    ]}
                    onPress={() => setEditedUser({...editedUser, role: 'admin'})}
                  >
                    <Text style={[
                      styles.pickerOptionText,
                      editedUser.role === 'admin' && styles.pickerOptionTextSelected
                    ]}>Admin</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View>

            <TouchableOpacity
              style={styles.saveButton}
              onPress={handleSaveUser}
            >
              <Save size={20} color={COLORS.white} />
              <Text style={styles.saveButtonText}>Save Changes</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.lightBackground,
  },
  centered: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  searchContainer: {
    flexDirection: 'row',
    padding: 16,
    backgroundColor: COLORS.white,
  },
  searchBar: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.lightBackground,
    borderRadius: 8,
    paddingHorizontal: 12,
    marginRight: 12,
  },
  searchInput: {
    flex: 1,
    paddingVertical: 10,
    marginLeft: 8,
  },
  filterButton: {
    backgroundColor: COLORS.lightBackground,
    width: 44,
    height: 44,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  listContainer: {
    padding: 16,
    paddingBottom: 80, // Space for the floating action button
  },
  userCard: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  userHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  userName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.darkGray,
  },
  statusBadge: {
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 12,
  },
  statusText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: COLORS.white,
  },
  userEmail: {
    fontSize: 14,
    color: COLORS.darkGray,
    marginBottom: 12,
  },
  userDetails: {
    borderTopWidth: 1,
    borderTopColor: COLORS.lightGray,
    paddingTop: 12,
    marginBottom: 12,
  },
  userDetail: {
    flexDirection: 'row',
    marginBottom: 4,
  },
  detailLabel: {
    fontSize: 14,
    color: COLORS.darkGray,
    width: 100,
  },
  detailValue: {
    fontSize: 14,
    color: COLORS.darkGray,
    fontWeight: '500',
  },
  userActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderTopWidth: 1,
    borderTopColor: COLORS.lightGray,
    paddingTop: 12,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 8,
  },
  actionText: {
    marginLeft: 4,
    fontSize: 14,
    color: COLORS.primary,
  },
  emptyContainer: {
    alignItems: 'center',
    padding: 20,
  },
  emptyText: {
    fontSize: 16,
    color: COLORS.darkGray,
  },
  addButton: {
    position: 'absolute',
    bottom: 20,
    right: 20,
    backgroundColor: COLORS.primary,
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
    elevation: 5,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    width: '90%',
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 5,
    elevation: 5,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.darkGray,
  },
  closeButton: {
    padding: 4,
  },
  formContainer: {
    marginBottom: 20,
  },
  formGroup: {
    marginBottom: 16,
  },
  formLabel: {
    fontSize: 16,
    fontWeight: '500',
    color: COLORS.darkGray,
    marginBottom: 8,
  },
  formInput: {
    borderWidth: 1,
    borderColor: COLORS.lightGray,
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 16,
  },
  pickerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  pickerOption: {
    borderWidth: 1,
    borderColor: COLORS.lightGray,
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 12,
    flex: 1,
    marginHorizontal: 4,
    alignItems: 'center',
  },
  pickerOptionSelected: {
    backgroundColor: COLORS.primary,
    borderColor: COLORS.primary,
  },
  pickerOptionText: {
    color: COLORS.darkGray,
    fontSize: 14,
  },
  pickerOptionTextSelected: {
    color: COLORS.white,
    fontWeight: '600',
  },
  saveButton: {
    flexDirection: 'row',
    backgroundColor: COLORS.primary,
    paddingVertical: 12,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  saveButtonText: {
    color: COLORS.white,
    fontSize: 16,
    fontWeight: 'bold',
    marginLeft: 8,
  },
});