import React, { useState, useEffect, useRef } from 'react';
import { 
  View, 
  Text, 
  StyleSheet,
  TextInput,
  TouchableOpacity,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  Image,
  Alert
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { COLORS } from '../../constants/theme';
import { Send, ChevronLeft, Star, Phone, MoveVertical as MoreVertical } from 'lucide-react-native';

export default function ChatRoom() {
  const { id, name } = useLocalSearchParams();
  const router = useRouter();
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([]);
  const [messageCount, setMessageCount] = useState(0);
  const [showPaymentPrompt, setShowPaymentPrompt] = useState(false);
  const flatListRef = useRef(null);

  // Initial messages
  useEffect(() => {
    setMessages([
      {
        id: '1',
        text: 'Hello! How can I help you today?',
        sender: 'astrologer',
        timestamp: new Date(Date.now() - 3600000).toISOString()
      }
    ]);
  }, []);

  const handleSend = () => {
    if (message.trim() === '') return;

    // Add user message
    const userMessage = {
      id: Date.now().toString(),
      text: message,
      sender: 'user',
      timestamp: new Date().toISOString()
    };
    
    setMessages(prevMessages => [...prevMessages, userMessage]);
    setMessage('');
    setMessageCount(prevCount => prevCount + 1);

    // Check if we've reached the free message limit
    if (messageCount === 4) { // 0-indexed, so this is the 5th message
      setTimeout(() => {
        setShowPaymentPrompt(true);
      }, 1000);
    } else {
      // Simulate astrologer reply after a short delay
      setTimeout(() => {
        const astrologerReplies = [
          "I can see that your planetary alignment suggests a period of change coming up.",
          "Based on your birth chart, Jupiter is in a favorable position right now.",
          "You might experience some challenges in the coming weeks, but they will lead to growth.",
          "The stars indicate that your communication skills will be enhanced this month.",
          "I would recommend a simple remedy to strengthen your Saturn."
        ];
        
        const astrologerMessage = {
          id: (Date.now() + 1).toString(),
          text: astrologerReplies[Math.floor(Math.random() * astrologerReplies.length)],
          sender: 'astrologer',
          timestamp: new Date().toISOString()
        };
        
        setMessages(prevMessages => [...prevMessages, astrologerMessage]);
      }, 1500);
    }
  };

  const handlePayment = () => {
    // In a real app, this would open the Razorpay payment gateway
    Alert.alert(
      "Proceed to Payment",
      "This would open the Razorpay payment gateway in a real app. After payment, you can continue chatting.",
      [
        {
          text: "Cancel",
          style: "cancel"
        },
        { 
          text: "Pay ₹199", 
          onPress: () => {
            setShowPaymentPrompt(false);
            
            // Add system message
            const systemMessage = {
              id: Date.now().toString(),
              text: "Payment successful! You can continue chatting.",
              sender: 'system',
              timestamp: new Date().toISOString()
            };
            
            setMessages(prevMessages => [...prevMessages, systemMessage]);
          }
        }
      ]
    );
  };

  const formatTime = (timestamp) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const renderMessage = ({ item }) => {
    const isUser = item.sender === 'user';
    const isSystem = item.sender === 'system';
    
    if (isSystem) {
      return (
        <View style={styles.systemMessageContainer}>
          <Text style={styles.systemMessageText}>{item.text}</Text>
        </View>
      );
    }
    
    return (
      <View style={[
        styles.messageContainer, 
        isUser ? styles.userMessageContainer : styles.astrologerMessageContainer
      ]}>
        {!isUser && (
          <Image 
            source={{ uri: 'https://9starsguru.com/wp-content/uploads/2025/03/DSC03026-scaled.jpg' }}
            style={styles.avatar}
          />
        )}
        <View style={[
          styles.messageBubble,
          isUser ? styles.userMessageBubble : styles.astrologerMessageBubble
        ]}>
          <Text style={[
            styles.messageText,
            isUser ? styles.userMessageText : styles.astrologerMessageText
          ]}>{item.text}</Text>
          <Text style={styles.timestampText}>{formatTime(item.timestamp)}</Text>
        </View>
      </View>
    );
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      style={styles.container}
      keyboardVerticalOffset={Platform.OS === "ios" ? 90 : 0}
    >
      {/* Chat Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <ChevronLeft size={24} color={COLORS.white} />
        </TouchableOpacity>
        
        <View style={styles.headerInfo}>
          <Text style={styles.headerName}>{name}</Text>
          <View style={styles.ratingContainer}>
            <View style={styles.onlineIndicator} />
            <Text style={styles.onlineText}>Online</Text>
            <Star size={14} color={COLORS.white} fill={COLORS.white} />
            <Text style={styles.ratingText}>4.8</Text>
          </View>
        </View>
        
        <View style={styles.headerActions}>
          <TouchableOpacity style={styles.headerActionButton}>
            <Phone size={20} color={COLORS.white} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.headerActionButton}>
            <MoreVertical size={20} color={COLORS.white} />
          </TouchableOpacity>
        </View>
      </View>
      
      {/* Chat Messages */}
      <FlatList
        ref={flatListRef}
        data={messages}
        renderItem={renderMessage}
        keyExtractor={item => item.id}
        style={styles.messagesList}
        contentContainerStyle={styles.messagesContainer}
        onContentSizeChange={() => flatListRef.current?.scrollToEnd()}
      />
      
      {/* Payment Prompt */}
      {showPaymentPrompt && (
        <View style={styles.paymentPrompt}>
          <Text style={styles.paymentPromptTitle}>Continue Chatting</Text>
          <Text style={styles.paymentPromptText}>
            You've used your 5 free messages. To continue chatting with {name}, please purchase a chat package.
          </Text>
          <TouchableOpacity style={styles.paymentButton} onPress={handlePayment}>
            <Text style={styles.paymentButtonText}>Pay ₹199 to Continue</Text>
          </TouchableOpacity>
        </View>
      )}
      
      {/* Message Input */}
      {!showPaymentPrompt && (
        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            placeholder="Type your message..."
            value={message}
            onChangeText={setMessage}
            multiline
          />
          <TouchableOpacity 
            style={[styles.sendButton, !message.trim() && styles.sendButtonDisabled]}
            onPress={handleSend}
            disabled={!message.trim()}
          >
            <Send size={20} color={COLORS.white} />
          </TouchableOpacity>
        </View>
      )}
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.lightBackground,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.primary,
    paddingVertical: 16,
    paddingHorizontal: 12,
  },
  backButton: {
    padding: 4,
  },
  headerInfo: {
    flex: 1,
    marginLeft: 12,
  },
  headerName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.white,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 4,
  },
  onlineIndicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: COLORS.success,
    marginRight: 4,
  },
  onlineText: {
    fontSize: 12,
    color: COLORS.white,
    marginRight: 12,
  },
  ratingText: {
    fontSize: 12,
    color: COLORS.white,
    marginLeft: 2,
  },
  headerActions: {
    flexDirection: 'row',
  },
  headerActionButton: {
    padding: 8,
    marginLeft: 8,
  },
  messagesList: {
    flex: 1,
  },
  messagesContainer: {
    padding: 16,
  },
  messageContainer: {
    flexDirection: 'row',
    marginBottom: 16,
    maxWidth: '80%',
  },
  userMessageContainer: {
    alignSelf: 'flex-end',
  },
  astrologerMessageContainer: {
    alignSelf: 'flex-start',
  },
  avatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    marginRight: 8,
  },
  messageBubble: {
    borderRadius: 16,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  userMessageBubble: {
    backgroundColor: COLORS.primary,
    borderBottomRightRadius: 4,
  },
  astrologerMessageBubble: {
    backgroundColor: COLORS.white,
    borderBottomLeftRadius: 4,
  },
  messageText: {
    fontSize: 16,
  },
  userMessageText: {
    color: COLORS.white,
  },
  astrologerMessageText: {
    color: COLORS.darkGray,
  },
  timestampText: {
    fontSize: 10,
    color: COLORS.lightGray,
    alignSelf: 'flex-end',
    marginTop: 4,
  },
  systemMessageContainer: {
    alignItems: 'center',
    marginVertical: 12,
  },
  systemMessageText: {
    fontSize: 12,
    color: COLORS.darkGray,
    backgroundColor: 'rgba(0,0,0,0.05)',
    paddingVertical: 4,
    paddingHorizontal: 12,
    borderRadius: 12,
  },
  paymentPrompt: {
    backgroundColor: COLORS.white,
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: COLORS.lightGray,
  },
  paymentPromptTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.darkGray,
    marginBottom: 8,
    textAlign: 'center',
  },
  paymentPromptText: {
    fontSize: 14,
    color: COLORS.darkGray,
    marginBottom: 16,
    textAlign: 'center',
  },
  paymentButton: {
    backgroundColor: COLORS.primary,
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  paymentButtonText: {
    color: COLORS.white,
    fontWeight: 'bold',
    fontSize: 16,
  },
  inputContainer: {
    flexDirection: 'row',
    padding: 12,
    backgroundColor: COLORS.white,
    borderTopWidth: 1,
    borderTopColor: COLORS.lightGray,
  },
  input: {
    flex: 1,
    backgroundColor: COLORS.lightBackground,
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 10,
    maxHeight: 100,
  },
  sendButton: {
    backgroundColor: COLORS.primary,
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 8,
  },
  sendButtonDisabled: {
    backgroundColor: COLORS.lightGray,
  },
});