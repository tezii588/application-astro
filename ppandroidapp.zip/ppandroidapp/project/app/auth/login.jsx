// import React, { useState } from 'react';
// import { 
//   View, 
//   Text, 
//   StyleSheet, 
//   TextInput, 
//   TouchableOpacity,
//   ScrollView,
//   KeyboardAvoidingView,
//   Platform,
//   Image
// } from 'react-native';
// import { useRouter } from 'expo-router';
// import { COLORS, SIZES, FONTS } from '../../constants/theme';
// import { loginUser } from '../../services/authService';
// import { storeUserData } from '../../utils/authUtils';
// import { Lock, Mail, User } from 'lucide-react-native';

// export default function Login() {
//   const router = useRouter();
//   const [email, setEmail] = useState('');
//   const [password, setPassword] = useState('');
//   const [role, setRole] = useState('user');
//   const [isLoading, setIsLoading] = useState(false);
//   const [error, setError] = useState('');

//   const handleLogin = async () => {
//     if (!email || !password) {
//       setError('Please fill in all fields');
//       return;
//     }

//     setIsLoading(true);
//     setError('');

//     try {
//       // Call login API
//       const userData = await loginUser(email, password, role);
      
//       // For demo purposes, we'll simulate a successful login
//       const mockUserData = {
//         id: '123',
//         name: email.split('@')[0],
//         email,
//         role,
//         token: 'mock-jwt-token-12345'
//       };
      
//       // Store user data
//       await storeUserData(mockUserData);
      
//       // Redirect based on role
//       if (role === 'admin') {
//         router.replace('/(admin)/dashboard');
//       } else {
//         router.replace('/(user)/dashboard');
//       }
//     } catch (error) {
//       console.error('Login error:', error);
//       setError('Invalid credentials. Please try again.');
//     } finally {
//       setIsLoading(false);
//     }
//   };

//   const handleRegister = () => {
//     router.push('/auth/register');
//   };

//   return (
//     <KeyboardAvoidingView 
//       behavior={Platform.OS === "ios" ? "padding" : "height"}
//       style={styles.container}
//     >
//       <ScrollView contentContainerStyle={styles.scrollContainer}>
//         <View style={styles.headerContainer}>
//   <Image
//     source={{ uri: 'https://9starsguru.com/wp-content/uploads/2025/04/WhatsApp-Image-2025-04-05-at-16.35.01.jpeg' }}
//     style={styles.logo}
//     resizeMode="contain"
//   />
//   <Text style={styles.headerText}>Astrological Guidance</Text>
// </View>


//         <View style={styles.formContainer}>
//           <Text style={styles.title}>9starsguruLogin</Text>
          
//           {error ? <Text style={styles.errorText}>{error}</Text> : null}
          
//           <View style={styles.inputContainer}>
//             <Mail size={20} color={COLORS.darkGray} />
//             <TextInput
//               style={styles.input}
//               placeholder="Email"
//               value={email}
//               onChangeText={setEmail}
//               keyboardType="email-address"
//               autoCapitalize="none"
//             />
//           </View>

//           <View style={styles.inputContainer}>
//             <Lock size={20} color={COLORS.darkGray} />
//             <TextInput
//               style={styles.input}
//               placeholder="Password"
//               value={password}
//               onChangeText={setPassword}
//               secureTextEntry
//             />
//           </View>

//           <Text style={styles.roleLabel}>Select Role:</Text>
//           <View style={styles.roleContainer}>
//             <TouchableOpacity 
//               style={[
//                 styles.roleButton, 
//                 role === 'user' && styles.roleButtonActive
//               ]}
//               onPress={() => setRole('user')}
//             >
//               <User size={18} color={role === 'user' ? COLORS.white : COLORS.primary} />
//               <Text style={[
//                 styles.roleText,
//                 role === 'user' && styles.roleTextActive
//               ]}>User</Text>
//             </TouchableOpacity>

//             <TouchableOpacity 
//               style={[
//                 styles.roleButton, 
//                 role === 'admin' && styles.roleButtonActive
//               ]}
//               onPress={() => setRole('admin')}
//             >
//               <Lock size={18} color={role === 'admin' ? COLORS.white : COLORS.primary} />
//               <Text style={[
//                 styles.roleText,
//                 role === 'admin' && styles.roleTextActive
//               ]}>Admin</Text>
//             </TouchableOpacity>
//           </View>

//           <TouchableOpacity 
//             style={styles.loginButton} 
//             onPress={handleLogin}
//             disabled={isLoading}
//           >
//             <Text style={styles.loginButtonText}>
//               {isLoading ? 'Logging In...' : 'Login'}
//             </Text>
//           </TouchableOpacity>

//           <TouchableOpacity onPress={handleRegister}>
//             <Text style={styles.registerText}>
//               Don't have an account? <Text style={styles.registerLink}>Register</Text>
//             </Text>
//           </TouchableOpacity>
//         </View>
//       </ScrollView>
//     </KeyboardAvoidingView>
//   );
// }

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: COLORS.white,
//   },
//   scrollContainer: {
//     flexGrow: 1,
//     paddingBottom: 40,
//   },
//   headerContainer: {
//     backgroundColor: COLORS.primary,
//     paddingVertical: 40,
//     paddingHorizontal: 20,
//     borderBottomLeftRadius: 30,
//     borderBottomRightRadius: 30,
//     alignItems: 'center',
//     marginBottom: 30,
//   },
//   logoText: {
//     fontSize: 32,
//     fontWeight: 'bold',
//     color: COLORS.white,
//     marginBottom: 8,
//   },
//   headerText: {
//     fontSize: 16,
//     color: COLORS.white,
//     opacity: 0.9,
//   },
//   formContainer: {
//     paddingHorizontal: 20,
//   },
//   title: {
//     fontSize: 24,
//     fontWeight: 'bold',
//     color: COLORS.darkGray,
//     marginBottom: 20,
//     textAlign: 'center',
//   },
//   inputContainer: {
//     flexDirection: 'row',
//     alignItems: 'center',
//     borderWidth: 1,
//     borderColor: COLORS.lightGray,
//     borderRadius: 8,
//     paddingHorizontal: 10,
//     marginBottom: 16,
//     height: 50,
//   },
//   input: {
//     flex: 1,
//     marginLeft: 10,
//     height: '100%',
//     color: COLORS.darkGray,
//   },
//   roleLabel: {
//     fontSize: 16,
//     fontWeight: '500',
//     color: COLORS.darkGray,
//     marginBottom: 10,
//   },
//   roleContainer: {
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//     marginBottom: 24,
//   },
//   roleButton: {
//     flexDirection: 'row',
//     alignItems: 'center',
//     justifyContent: 'center',
//     borderWidth: 1,
//     borderColor: COLORS.primary,
//     borderRadius: 8,
//     paddingVertical: 10,
//     paddingHorizontal: 20,
//     width: '48%',
//   },
//   roleButtonActive: {
//     backgroundColor: COLORS.primary,
//     borderColor: COLORS.primary,
//   },
//   roleText: {
//     fontSize: 16,
//     fontWeight: '500',
//     color: COLORS.primary,
//     marginLeft: 8,
//   },
//   roleTextActive: {
//     color: COLORS.white,
//   },
//   loginButton: {
//     backgroundColor: COLORS.primary,
//     borderRadius: 8,
//     paddingVertical: 15,
//     alignItems: 'center',
//     marginBottom: 20,
//     shadowColor: COLORS.primary,
//     shadowOffset: { width: 0, height: 4 },
//     shadowOpacity: 0.3,
//     shadowRadius: 8,
//     elevation: 5,
//   },
//   loginButtonText: {
//     color: COLORS.white,
//     fontSize: 16,
//     fontWeight: 'bold',
//   },
//   registerText: {
//     textAlign: 'center',
//     color: COLORS.darkGray,
//   },
//   registerLink: {
//     color: COLORS.primary,
//     fontWeight: 'bold',
//   },
//   errorText: {
//     color: COLORS.error,
//     marginBottom: 15,
//     textAlign: 'center',
//   },
// });

import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TextInput, 
  TouchableOpacity,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Image
} from 'react-native';
import { useRouter } from 'expo-router';
import { COLORS, SIZES, FONTS } from '../../constants/theme';
import { loginUser } from '../../services/authService';
import { storeUserData } from '../../utils/authUtils';
import { Lock, Mail, User } from 'lucide-react-native';

export default function Login() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('user');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = async () => {
    if (!email || !password) {
      setError('Please fill in all fields');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      // Call login API
      const userData = await loginUser(email, password, role);
      
      // For demo purposes, we'll simulate a successful login
      const mockUserData = {
        id: '123',
        name: email.split('@')[0],
        email,
        role,
        token: 'mock-jwt-token-12345'
      };
      
      // Store user data
      await storeUserData(mockUserData);
      
      // Redirect based on role
      if (role === 'admin') {
        router.replace('/(admin)/dashboard');
      } else {
        router.replace('/(user)/dashboard');
      }
    } catch (error) {
      console.error('Login error:', error);
      setError('Invalid credentials. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegister = () => {
    router.push('/auth/register');
  };

  return (
    <KeyboardAvoidingView 
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      style={styles.container}
    >
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.headerContainer}>
          <Image
            source={{ uri: 'https://9starsguru.com/wp-content/uploads/2025/04/WhatsApp-Image-2025-04-05-at-16.35.01.jpeg' }}
            style={styles.logo}
            resizeMode="contain"
          />
          <Text style={styles.headerText}>Astrological Guidance</Text>
        </View>

        <View style={styles.formContainer}>
          <Text style={styles.title}>Login</Text>
          
          {error ? <Text style={styles.errorText}>{error}</Text> : null}
          
          <View style={styles.inputContainer}>
            <Mail size={20} color={COLORS.darkGray} />
            <TextInput
              style={styles.input}
              placeholder="Email"
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              autoCapitalize="none"
            />
          </View>

          <View style={styles.inputContainer}>
            <Lock size={20} color={COLORS.darkGray} />
            <TextInput
              style={styles.input}
              placeholder="Password"
              value={password}
              onChangeText={setPassword}
              secureTextEntry
            />
          </View>

          <Text style={styles.roleLabel}>Select Role:</Text>
          <View style={styles.roleContainer}>
            <TouchableOpacity 
              style={[
                styles.roleButton, 
                role === 'user' && styles.roleButtonActive
              ]}
              onPress={() => setRole('user')}
            >
              <User size={18} color={role === 'user' ? COLORS.white : COLORS.primary} />
              <Text style={[
                styles.roleText,
                role === 'user' && styles.roleTextActive
              ]}>User</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              style={[
                styles.roleButton, 
                role === 'admin' && styles.roleButtonActive
              ]}
              onPress={() => setRole('admin')}
            >
              <Lock size={18} color={role === 'admin' ? COLORS.white : COLORS.primary} />
              <Text style={[
                styles.roleText,
                role === 'admin' && styles.roleTextActive
              ]}>Admin</Text>
            </TouchableOpacity>
          </View>

          <TouchableOpacity 
            style={styles.loginButton} 
            onPress={handleLogin}
            disabled={isLoading}
          >
            <Text style={styles.loginButtonText}>
              {isLoading ? 'Logging In...' : 'Login'}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={handleRegister}>
            <Text style={styles.registerText}>
              Don't have an account? <Text style={styles.registerLink}>Register</Text>
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  scrollContainer: {
    flexGrow: 1,
    paddingBottom: 40,
  },
  headerContainer: {
   backgroundColor: '#301005', // light orange
    paddingVertical: 40,
    paddingHorizontal: 20,
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
    alignItems: 'center',
    marginBottom: 30,
  },
  logo: {
    width: 120,
    height: 120,
    marginBottom: 12,
    borderRadius: 60,  // round shape for logo, remove if you want square
  },
  headerText: {
    fontSize: 16,
    color: COLORS.white,
    opacity: 0.9,
  },
  formContainer: {
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.darkGray,
    marginBottom: 20,
    textAlign: 'center',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: COLORS.lightGray,
    borderRadius: 8,
    paddingHorizontal: 10,
    marginBottom: 16,
    height: 50,
  },
  input: {
    flex: 1,
    marginLeft: 10,
    height: '100%',
    color: COLORS.darkGray,
  },
  roleLabel: {
    fontSize: 16,
    fontWeight: '500',
    color: COLORS.darkGray,
    marginBottom: 10,
  },
  roleContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  roleButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: COLORS.primary,
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 20,
    width: '48%',
  },
  roleButtonActive: {
    backgroundColor:'#301005',
    borderColor: '#301005',
  },
  roleText: {
    fontSize: 16,
    fontWeight: '500',
    color: COLORS.primary,
    marginLeft: 8,
  },
  roleTextActive: {
    color: COLORS.white,
  },
  loginButton: {
    backgroundColor: COLORS.primary,
    borderRadius: 8,
    paddingVertical: 15,
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 5,
  },
  loginButtonText: {
    color: COLORS.white,
    fontSize: 16,
    fontWeight: 'bold',
  },
  registerText: {
    textAlign: 'center',
    color: COLORS.darkGray,
  },
  registerLink: {
    color: COLORS.primary,
    fontWeight: 'bold',
  },
  errorText: {
    color: COLORS.error,
    marginBottom: 15,
    textAlign: 'center',
  },
});
