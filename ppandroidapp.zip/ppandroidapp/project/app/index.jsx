import React, { useEffect } from 'react';
import { View, Text, StyleSheet, ActivityIndicator } from 'react-native';
import { useRouter, Redirect } from 'expo-router';
import { getUserData } from '../utils/authUtils';
import { COLORS } from '../constants/theme';

export default function Index() {
  const router = useRouter();

  useEffect(() => {
    // Check if user is already logged in
    const checkAuthStatus = async () => {
      try {
        const userData = await getUserData();
        if (userData) {
          // User is authenticated, redirect to appropriate dashboard
          const destination = userData.role === 'admin' ? '/(admin)/dashboard' : '/(user)/dashboard';
          router.replace(destination);
        } else {
          // User is not authenticated, redirect to login
          router.replace('/auth/login');
        }
      } catch (error) {
        console.error('Error checking auth status:', error);
        router.replace('/auth/login');
      }
    };

    checkAuthStatus();
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>9StarsGuru</Text>
      <ActivityIndicator size="large" color={COLORS.primary} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.white
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: COLORS.primary,
    marginBottom: 20
  }
});