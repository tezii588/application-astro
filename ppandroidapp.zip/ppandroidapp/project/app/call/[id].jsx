import React, { useState, useEffect, useRef } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  Image,
  Alert,
  BackHandler,
  Dimensions,
  Animated
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { COLORS } from '../../constants/theme';
import { 
  MicOff, 
  PhoneOff, 
  Volume2, 
  Minimize, 
  Timer
} from 'lucide-react-native';

const { width, height } = Dimensions.get('window');

export default function CallScreen() {
  const { id, name, price, image } = useLocalSearchParams();
  const router = useRouter();
  const [seconds, setSeconds] = useState(0);
  const [muted, setMuted] = useState(false);
  const [speakerOn, setSpeakerOn] = useState(false);
  const [walletBalance, setWalletBalance] = useState(500); // Initial balance from payment
  const [minimized, setMinimized] = useState(false);
  const minimizeAnim = useRef(new Animated.Value(1)).current;
  const positionAnim = useRef(new Animated.ValueXY({ x: 0, y: 0 })).current;

  // Format seconds to MM:SS
  const formatTime = (totalSeconds) => {
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  // Calculate cost based on time
  const calculateCost = () => {
    return (seconds / 60) * parseFloat(price);
  };

  // Start timer and deduct balance
  useEffect(() => {
    const timer = setInterval(() => {
      setSeconds(prev => prev + 1);
      
      // Deduct money every minute
      if (seconds > 0 && seconds % 60 === 0) {
        setWalletBalance(prev => {
          const newBalance = prev - parseFloat(price);
          
          // Check if balance is low
          if (newBalance < parseFloat(price) * 2) {
            Alert.alert(
              "Low Balance",
              "Your wallet balance is low. The call will end when your balance is insufficient.",
              [{ text: "OK" }]
            );
          }
          
          // End call if balance is insufficient
          if (newBalance <= 0) {
            clearInterval(timer);
            Alert.alert(
              "Call Ended",
              "Your call has ended due to insufficient balance.",
              [{ text: "OK", onPress: () => router.back() }]
            );
            return 0;
          }
          
          return newBalance;
        });
      }
    }, 1000);
    
    // Handle back button
    const backHandler = BackHandler.addEventListener(
      "hardwareBackPress",
      () => {
        handleEndCall();
        return true;
      }
    );
    
    return () => {
      clearInterval(timer);
      backHandler.remove();
    };
  }, [seconds]);

  // Handle ending the call
  const handleEndCall = () => {
    Alert.alert(
      "End Call",
      "Are you sure you want to end this call?",
      [
        {
          text: "Cancel",
          style: "cancel"
        },
        { 
          text: "End Call", 
          onPress: () => {
            Alert.alert(
              "Call Summary",
              `Call duration: ${formatTime(seconds)}\nTotal cost: ₹${calculateCost().toFixed(2)}`,
              [{ text: "OK", onPress: () => router.back() }]
            );
          },
          style: "destructive"
        }
      ]
    );
  };

  // Toggle minimize state with animation
  const toggleMinimize = () => {
    if (minimized) {
      // Expand
      Animated.parallel([
        Animated.timing(minimizeAnim, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true
        }),
        Animated.timing(positionAnim, {
          toValue: { x: 0, y: 0 },
          duration: 300,
          useNativeDriver: true
        })
      ]).start();
    } else {
      // Minimize
      Animated.parallel([
        Animated.timing(minimizeAnim, {
          toValue: 0.25,
          duration: 300,
          useNativeDriver: true
        }),
        Animated.timing(positionAnim, {
          toValue: { x: width * 0.35, y: -height * 0.35 },
          duration: 300,
          useNativeDriver: true
        })
      ]).start();
    }
    setMinimized(!minimized);
  };

  // Calculate transformed styles
  const containerStyle = {
    transform: [
      { scale: minimizeAnim },
      { translateX: positionAnim.x },
      { translateY: positionAnim.y }
    ]
  };

  return (
    <Animated.View style={[styles.container, containerStyle]}>
      <Image 
        source={{ uri: image }}
        style={styles.astrologerImage}
        resizeMode="cover"
      />
      
      <View style={styles.overlay}>
        {/* Call Info */}
        <View style={styles.callInfo}>
          <TouchableOpacity 
            style={styles.minimizeButton}
            onPress={toggleMinimize}
          >
            <Minimize size={24} color={COLORS.white} />
          </TouchableOpacity>
          
          <Text style={styles.name}>{name}</Text>
          <View style={styles.callStatus}>
            <Timer size={16} color={COLORS.white} />
            <Text style={styles.timeText}>{formatTime(seconds)}</Text>
          </View>
          
          <View style={styles.balanceContainer}>
            <Text style={styles.balanceLabel}>Wallet Balance:</Text>
            <Text style={styles.balanceAmount}>₹{walletBalance.toFixed(2)}</Text>
          </View>
          
          <View style={styles.costContainer}>
            <Text style={styles.costLabel}>Current Cost:</Text>
            <Text style={styles.costAmount}>₹{calculateCost().toFixed(2)}</Text>
          </View>
        </View>
        
        {/* Call Controls */}
        <View style={styles.controls}>
          <TouchableOpacity 
            style={[styles.controlButton, muted && styles.activeControl]}
            onPress={() => setMuted(!muted)}
          >
            <MicOff size={24} color={COLORS.white} />
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.endCallButton}
            onPress={handleEndCall}
          >
            <PhoneOff size={24} color={COLORS.white} />
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[styles.controlButton, speakerOn && styles.activeControl]}
            onPress={() => setSpeakerOn(!speakerOn)}
          >
            <Volume2 size={24} color={COLORS.white} />
          </TouchableOpacity>
        </View>
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.black,
  },
  astrologerImage: {
    width: '100%',
    height: '100%',
    opacity: 0.7,
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'space-between',
    padding: 24,
  },
  callInfo: {
    alignItems: 'center',
    marginTop: 60,
  },
  minimizeButton: {
    position: 'absolute',
    top: -40,
    right: 0,
    padding: 8,
  },
  name: {
    fontSize: 28,
    fontWeight: 'bold',
    color: COLORS.white,
    marginBottom: 8,
  },
  callStatus: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.4)',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 16,
    marginBottom: 24,
  },
  timeText: {
    color: COLORS.white,
    marginLeft: 8,
    fontWeight: '500',
  },
  balanceContainer: {
    flexDirection: 'row',
    backgroundColor: 'rgba(0,0,0,0.4)',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
    marginBottom: 12,
    alignItems: 'center',
  },
  balanceLabel: {
    color: COLORS.white,
    marginRight: 8,
  },
  balanceAmount: {
    color: COLORS.white,
    fontWeight: 'bold',
  },
  costContainer: {
    flexDirection: 'row',
    backgroundColor: 'rgba(0,0,0,0.4)',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  costLabel: {
    color: COLORS.white,
    marginRight: 8,
  },
  costAmount: {
    color: COLORS.primary,
    fontWeight: 'bold',
  },
  controls: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    marginBottom: 40,
  },
  controlButton: {
    backgroundColor: 'rgba(0,0,0,0.6)',
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
  },
  activeControl: {
    backgroundColor: COLORS.primary,
  },
  endCallButton: {
    backgroundColor: COLORS.error,
    width: 70,
    height: 70,
    borderRadius: 35,
    justifyContent: 'center',
    alignItems: 'center',
  },
});