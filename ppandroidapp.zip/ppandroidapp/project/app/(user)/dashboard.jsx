import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity, 
  Image,
  Alert
} from 'react-native';
import { COLORS, SIZES, FONTS } from '../../constants/theme';
import { 
  MessageCircle, 
  Phone, 
  FileText, 
  Compass, 
  Plus, 
  Star
} from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';
import ServiceCard from '../../components/ServiceCard';

export default function Dashboard() {
  const [walletBalance, setWalletBalance] = useState(1000); // Initial balance for demo

  const handleAddMoney = () => {
    // In a real app, this would open the Razorpay payment gateway
    Alert.alert(
      "Add Money to Wallet",
      "This would open the Razorpay payment gateway in a real app.",
      [
        {
          text: "Cancel",
          style: "cancel"
        },
        { 
          text: "Add ₹500", 
          onPress: () => {
            setWalletBalance(walletBalance + 500);
            Alert.alert("Success", "Added ₹500 to your wallet!");
          }
        }
      ]
    );
  };

  const services = [
    {
      id: '1',
      title: 'Chat with Astrologer',
      icon: <MessageCircle size={24} color={COLORS.primary} />,
      route: '/chat'
    },
    {
      id: '2',
      title: 'Call Consultation',
      icon: <Phone size={24} color={COLORS.primary} />,
      route: '/call'
    },
    {
      id: '3',
      title: 'Kundali Analysis',
      icon: <FileText size={24} color={COLORS.primary} />,
      route: '/kundali'
    },
    {
      id: '4',
      title: 'Remedies',
      icon: <Compass size={24} color={COLORS.primary} />,
      route: '/remedies'
    }
  ];

  // Today's horoscope data
  const horoscope = {
    sign: 'Aries',
    date: 'June 10, 2025',
    description: 'Today is a good day for new beginnings. Your energy is high and you\'re ready to take on challenges. Focus on your goals and don\'t get distracted by minor issues.'
  };

  // Featured astrologers
  const featuredAstrologers = [
    {
      id: '1',
      name: 'Eshwar',
      specialty: 'Vedic Astrology',
      rating: 4.8,
      experience: '15 years',
      image: 'https://9starsguru.com/wp-content/uploads/2025/03/DSC03033-scaled.jpg'
    },
    {
      id: '2',
      name: 'Bharani',
      specialty: 'Tarot Reading',
      rating: 4.7,
      experience: '15 years',
      image: 'https://9starsguru.com/wp-content/uploads/2025/03/DSC03006-scaled.jpg'
    }
    
  ];

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Wallet Section */}
      <View style={styles.walletCard}>
        <View style={styles.walletInfo}>
          <Text style={styles.walletLabel}>Wallet Balance</Text>
          <Text style={styles.walletBalance}>₹{walletBalance.toFixed(2)}</Text>
        </View>
        <TouchableOpacity style={styles.addButton} onPress={handleAddMoney}>
          <Plus size={16} color={COLORS.white} />
          <Text style={styles.addButtonText}>Add Money</Text>
        </TouchableOpacity>
      </View>

      {/* Hero Banner */}
      <LinearGradient
        colors={[COLORS.primary, COLORS.secondary]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0 }}
        style={styles.heroBanner}
      >
        <View style={styles.heroContent}>
          <Text style={styles.heroTitle}>Discover Your Destiny</Text>
          <Text style={styles.heroSubtitle}>Get guidance from expert astrologers</Text>
          <TouchableOpacity style={styles.heroButton}>
            <Text style={styles.heroButtonText}>Explore Now</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.heroImageContainer}>
          <Image 
            source={{ uri: 'https://vedicastrologerkapoor.com/blogs/147/image/positive-and-negative-zodiac-signs-in-astrology.jpg' }}
            style={styles.heroImage}
            resizeMode="contain"
          />
        </View>
      </LinearGradient>

      {/* Services Section */}
      <View style={styles.sectionContainer}>
        <Text style={styles.sectionTitle}>Our Services</Text>
        <View style={styles.servicesGrid}>
          {services.map(service => (
            <ServiceCard 
              key={service.id}
              title={service.title}
              icon={service.icon}
              route={service.route}
            />
          ))}
        </View>
      </View>

      {/* Today's Horoscope */}
      <View style={styles.sectionContainer}>
        <Text style={styles.sectionTitle}>Today's Horoscope</Text>
        <View style={styles.horoscopeCard}>
          <View style={styles.horoscopeHeader}>
            <Text style={styles.horoscopeSign}>{horoscope.sign}</Text>
            <Text style={styles.horoscopeDate}>{horoscope.date}</Text>
          </View>
          <Text style={styles.horoscopeDescription}>{horoscope.description}</Text>
          <TouchableOpacity style={styles.horoscopeButton}>
            <Text style={styles.horoscopeButtonText}>Read Full Horoscope</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Featured Astrologers */}
      <View style={styles.sectionContainer}>
        <Text style={styles.sectionTitle}>Featured Astrologers</Text>
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.astrologersContainer}
        >
          {featuredAstrologers.map(astrologer => (
            <TouchableOpacity key={astrologer.id} style={styles.astrologerCard}>
              <Image 
                source={{ uri: astrologer.image }}
                style={styles.astrologerImage}
              />
              <View style={styles.astrologerInfo}>
                <Text style={styles.astrologerName}>{astrologer.name}</Text>
                <Text style={styles.astrologerSpecialty}>{astrologer.specialty}</Text>
                <View style={styles.astrologerRating}>
                  <Star size={16} color={COLORS.primary} fill={COLORS.primary} />
                  <Text style={styles.ratingText}>{astrologer.rating} • {astrologer.experience}</Text>
                </View>
              </View>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.lightBackground,
  },
  walletCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderRadius: 12,
    padding: 16,
    margin: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  walletInfo: {
    flex: 1,
  },
  walletLabel: {
    fontSize: 14,
    color: COLORS.darkGray,
  },
  walletBalance: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.black,
    marginTop: 4,
  },
  addButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.primary,
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
  },
  addButtonText: {
    color: COLORS.white,
    fontWeight: '600',
    marginLeft: 4,
  },
  heroBanner: {
    flexDirection: 'row',
    borderRadius: 12,
    marginHorizontal: 16,
    marginBottom: 24,
    padding: 16,
    overflow: 'hidden',
    height: 160,
  },
  heroContent: {
    flex: 1,
    justifyContent: 'center',
  },
  heroTitle: {
    color: COLORS.white,
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  heroSubtitle: {
    color: COLORS.white,
    opacity: 0.9,
    fontSize: 14,
    marginBottom: 16,
  },
  heroButton: {
    backgroundColor: COLORS.white,
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 6,
    alignSelf: 'flex-start',
  },
  heroButtonText: {
    color: COLORS.primary,
    fontWeight: '600',
  },
  heroImageContainer: {
    width: 100,
    justifyContent: 'center',
    alignItems: 'center',
  },
  heroImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
  },
  sectionContainer: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.darkGray,
    marginBottom: 16,
    marginHorizontal: 16,
  },
  servicesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginHorizontal: 16,
  },
  horoscopeCard: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    padding: 16,
    marginHorizontal: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  horoscopeHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  horoscopeSign: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.primary,
  },
  horoscopeDate: {
    fontSize: 14,
    color: COLORS.darkGray,
  },
  horoscopeDescription: {
    fontSize: 14,
    color: COLORS.darkGray,
    lineHeight: 20,
    marginBottom: 16,
  },
  horoscopeButton: {
    alignSelf: 'flex-end',
  },
  horoscopeButtonText: {
    color: COLORS.primary,
    fontWeight: '600',
  },
  astrologersContainer: {
    paddingHorizontal: 16,
    paddingBottom: 8,
  },
  astrologerCard: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    width: 200,
    marginRight: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
    overflow: 'hidden',
  },
  astrologerImage: {
    width: '100%',
    height: 140,
  },
  astrologerInfo: {
    padding: 12,
  },
  astrologerName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.black,
    marginBottom: 4,
  },
  astrologerSpecialty: {
    fontSize: 14,
    color: COLORS.darkGray,
    marginBottom: 8,
  },
  astrologerRating: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  ratingText: {
    fontSize: 14,
    color: COLORS.darkGray,
    marginLeft: 4,
  },
});