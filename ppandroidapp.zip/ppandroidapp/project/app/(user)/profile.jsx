import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  Image, 
  TouchableOpacity, 
  ScrollView,
  Alert 
} from 'react-native';
import { useRouter } from 'expo-router';
import { COLORS } from '../../constants/theme';
import { User, LogOut, CreditCard, Calendar, MessageCircle, Star, CircleHelp as HelpCircle, ChevronRight, Settings } from 'lucide-react-native';
import { getUserData, clearUserData } from '../../utils/authUtils';

export default function Profile() {
  const router = useRouter();
  const [userData, setUserData] = useState({
    name: 'Loading...',
    email: 'Loading...',
  });

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const data = await getUserData();
        if (data) {
          setUserData(data);
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    };
    
    fetchUserData();
  }, []);

  const handleLogout = async () => {
    Alert.alert(
      "Logout",
      "Are you sure you want to logout?",
      [
        {
          text: "Cancel",
          style: "cancel"
        },
        { 
          text: "Logout", 
          onPress: async () => {
            await clearUserData();
            router.replace('/auth/login');
          }
        }
      ]
    );
  };

  const profileSections = [
    {
      id: 'birth',
      title: 'Birth Details',
      icon: <Calendar size={20} color={COLORS.primary} />,
      action: () => {}
    },
    {
      id: 'consultations',
      title: 'Consultation History',
      icon: <MessageCircle size={20} color={COLORS.primary} />,
      action: () => {}
    },
    {
      id: 'transactions',
      title: 'Transaction History',
      icon: <CreditCard size={20} color={COLORS.primary} />,
      action: () => {}
    },
    {
      id: 'favorites',
      title: 'Favorite Astrologers',
      icon: <Star size={20} color={COLORS.primary} />,
      action: () => {}
    },
    {
      id: 'support',
      title: 'Help and Support',
      icon: <HelpCircle size={20} color={COLORS.primary} />,
      action: () => {}
    },
    {
      id: 'settings',
      title: 'Settings',
      icon: <Settings size={20} color={COLORS.primary} />,
      action: () => {}
    }
  ];

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Profile Header */}
      <View style={styles.profileHeader}>
        <View style={styles.profileImageContainer}>
          <Image 
            source={{ uri: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2' }}
            style={styles.profileImage}
          />
          <TouchableOpacity style={styles.editButton}>
            <User size={16} color={COLORS.white} />
          </TouchableOpacity>
        </View>
        <Text style={styles.profileName}>{userData.name}</Text>
        <Text style={styles.profileEmail}>{userData.email}</Text>
      </View>

      {/* Profile Card */}
      <View style={styles.profileCard}>
        <Text style={styles.sectionTitle}>Your Information</Text>
        
        <View style={styles.infoItem}>
          <Text style={styles.infoLabel}>Account Type</Text>
          <View style={styles.accountTypeTag}>
            <Text style={styles.accountTypeText}>{userData.role || 'User'}</Text>
          </View>
        </View>
        
        <View style={styles.infoItem}>
          <Text style={styles.infoLabel}>Joined On</Text>
          <Text style={styles.infoValue}>June 05, 2025</Text>
        </View>
        
        <View style={styles.infoItem}>
          <Text style={styles.infoLabel}>Mobile Number</Text>
          <Text style={styles.infoValue}>+91 98765 43210</Text>
        </View>
      </View>

      {/* Profile Sections */}
      <View style={styles.sectionsContainer}>
        {profileSections.map(section => (
          <TouchableOpacity 
            key={section.id}
            style={styles.sectionItem}
            onPress={section.action}
          >
            <View style={styles.sectionItemLeft}>
              {section.icon}
              <Text style={styles.sectionItemText}>{section.title}</Text>
            </View>
            <ChevronRight size={20} color={COLORS.darkGray} />
          </TouchableOpacity>
        ))}
      </View>

      {/* Logout Button */}
      <TouchableOpacity 
        style={styles.logoutButton}
        onPress={handleLogout}
      >
        <LogOut size={20} color={COLORS.error} />
        <Text style={styles.logoutText}>Logout</Text>
      </TouchableOpacity>

      {/* Version Info */}
      <Text style={styles.versionText}>Version 1.0.0</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.lightBackground,
  },
  profileHeader: {
    alignItems: 'center',
    paddingVertical: 24,
    paddingHorizontal: 16,
    backgroundColor: COLORS.white,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.lightGray,
  },
  profileImageContainer: {
    position: 'relative',
    marginBottom: 16,
  },
  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    borderWidth: 3,
    borderColor: COLORS.primary,
  },
  editButton: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    backgroundColor: COLORS.primary,
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: COLORS.white,
  },
  profileName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.darkGray,
    marginBottom: 4,
  },
  profileEmail: {
    fontSize: 14,
    color: COLORS.darkGray,
    opacity: 0.8,
  },
  profileCard: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    padding: 16,
    margin: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.darkGray,
    marginBottom: 16,
  },
  infoItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.lightGray,
  },
  infoLabel: {
    fontSize: 14,
    color: COLORS.darkGray,
  },
  infoValue: {
    fontSize: 14,
    color: COLORS.darkGray,
    fontWeight: '500',
  },
  accountTypeTag: {
    backgroundColor: COLORS.primary,
    paddingVertical: 4,
    paddingHorizontal: 12,
    borderRadius: 12,
  },
  accountTypeText: {
    color: COLORS.white,
    fontSize: 12,
    fontWeight: 'bold',
    textTransform: 'capitalize',
  },
  sectionsContainer: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    padding: 8,
    margin: 16,
    marginTop: 0,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  sectionItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 12,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.lightGray,
  },
  sectionItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  sectionItemText: {
    fontSize: 16,
    color: COLORS.darkGray,
    marginLeft: 12,
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.white,
    borderRadius: 12,
    padding: 16,
    margin: 16,
    marginTop: 0,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  logoutText: {
    fontSize: 16,
    color: COLORS.error,
    fontWeight: '600',
    marginLeft: 8,
  },
  versionText: {
    textAlign: 'center',
    fontSize: 12,
    color: COLORS.darkGray,
    opacity: 0.6,
    marginTop: 8,
    marginBottom: 24,
  },
});