import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  FlatList, 
  TouchableOpacity, 
  Image,
  Alert
} from 'react-native';
import { useRouter } from 'expo-router';
import { COLORS } from '../../constants/theme';
import { MessageCircle, Star, Clock } from 'lucide-react-native';

export default function Chat() {
  const router = useRouter();
  const [astrologers, setAstrologers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulating API call to fetch astrologers
    setTimeout(() => {
      setAstrologers([
        {
          id: '1',
          name: 'Eshwar',
          specialty: 'Vedic Astrology',
          experience: '15+ years',
          languages: ['Hindi', 'English'],
          rating: 4.8,
          price: 20,
          online: true,
          image: 'https://9starsguru.com/wp-content/uploads/2025/03/DSC03033-scaled.jpg'
        },
        {
          id: '2',
          name: 'Sri Satri',
          specialty: 'Tarot Reading',
          experience: '12+ years',
          languages: ['Hindi', 'English', 'Tamil'],
          rating: 4.7,
          price: 25,
          online: true,
          image: 'https://9starsguru.com/wp-content/uploads/2025/03/DSC03026-scaled.jpg'
        },
        {
          id: '3',
          name: 'Kamalakar',
          specialty: 'Numerology',
          experience: '10+ years',
          languages: ['Hindi', 'English', 'Marathi'],
          rating: 4.5,
          price: 15,
          online: true,
          image: 'https://9starsguru.com/wp-content/uploads/2025/03/DSC03040-scaled.jpg'
        },
        {
          id: '4',
          name: 'Kamalathi',
          specialty: 'Palmistry',
          experience: '8+ years',
          languages: ['Hindi', 'English', 'Gujarati'],
          rating: 4.6,
          price: 18,
          online: false,
          image: 'https://9starsguru.com/wp-content/uploads/2025/03/DSC03009-scaled.jpg'
        }
      ]);
      setLoading(false);
    }, 1000);
  }, []);

  const handleChatStart = (astrologer) => {
    if (!astrologer.online) {
      Alert.alert(
        "Astrologer Offline",
        "This astrologer is currently offline. Please try again later or choose another astrologer."
      );
      return;
    }
    
    router.push({
      pathname: '/chat/[id]',
      params: { id: astrologer.id, name: astrologer.name }
    });
  };

  const renderAstrologerCard = ({ item }) => {
    return (
      <TouchableOpacity 
        style={styles.astrologerCard}
        onPress={() => handleChatStart(item)}
        activeOpacity={0.7}
      >
        <View style={styles.astrologerHeader}>
          <Image 
            source={{ uri: item.image }}
            style={styles.astrologerImage}
          />
          <View style={[
            styles.statusIndicator, 
            { backgroundColor: item.online ? COLORS.success : COLORS.darkGray }
          ]} />
        </View>
        
        <View style={styles.astrologerInfo}>
          <Text style={styles.astrologerName}>{item.name}</Text>
          <Text style={styles.astrologerSpecialty}>{item.specialty}</Text>
          
          <View style={styles.ratingContainer}>
            <Star size={16} color={COLORS.primary} fill={COLORS.primary} />
            <Text style={styles.ratingText}>{item.rating}</Text>
          </View>
          
          <Text style={styles.experienceText}>
            <Clock size={14} color={COLORS.darkGray} /> {item.experience}
          </Text>
          
          <Text style={styles.languagesText}>
            {item.languages.join(' • ')}
          </Text>
          
          <View style={styles.priceContainer}>
            <Text style={styles.priceLabel}>₹{item.price}/min</Text>
            <TouchableOpacity 
              style={[
                styles.chatButton,
                !item.online && styles.chatButtonDisabled
              ]}
              onPress={() => handleChatStart(item)}
              disabled={!item.online}
            >
              <MessageCircle size={16} color={COLORS.white} />
              <Text style={styles.chatButtonText}>Chat</Text>
            </TouchableOpacity>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  if (loading) {
    return (
      <View style={[styles.container, styles.centered]}>
        <Text>Loading astrologers...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.filterBar}>
        <Text style={styles.filterText}>Online Astrologers</Text>
        <TouchableOpacity>
          <Text style={styles.filterAction}>Filter</Text>
        </TouchableOpacity>
      </View>
      
      <FlatList
        data={astrologers}
        renderItem={renderAstrologerCard}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listContainer}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.lightBackground,
  },
  centered: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  filterBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: COLORS.white,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.lightGray,
  },
  filterText: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.darkGray,
  },
  filterAction: {
    fontSize: 14,
    color: COLORS.primary,
    fontWeight: '600',
  },
  listContainer: {
    padding: 16,
  },
  astrologerCard: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    marginBottom: 16,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  astrologerHeader: {
    position: 'relative',
  },
  astrologerImage: {
    width: '100%',
    height: 180,
  },
  statusIndicator: {
    position: 'absolute',
    top: 12,
    right: 12,
    width: 12,
    height: 12,
    borderRadius: 6,
    borderWidth: 2,
    borderColor: COLORS.white,
  },
  astrologerInfo: {
    padding: 16,
  },
  astrologerName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.black,
    marginBottom: 4,
  },
  astrologerSpecialty: {
    fontSize: 14,
    color: COLORS.darkGray,
    marginBottom: 8,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  ratingText: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.darkGray,
    marginLeft: 4,
  },
  experienceText: {
    fontSize: 14,
    color: COLORS.darkGray,
    marginBottom: 4,
  },
  languagesText: {
    fontSize: 14,
    color: COLORS.darkGray,
    marginBottom: 12,
  },
  priceContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 8,
  },
  priceLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.primary,
  },
  chatButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.primary,
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
  },
  chatButtonDisabled: {
    backgroundColor: COLORS.lightGray,
  },
  chatButtonText: {
    color: COLORS.white,
    fontWeight: '600',
    marginLeft: 4,
  },
});