import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  FlatList, 
  TouchableOpacity, 
  Image,
  Alert
} from 'react-native';
import { COLORS } from '../../constants/theme';
import { Phone, Star, Clock, PhoneCall } from 'lucide-react-native';
import { useRouter } from 'expo-router';

export default function Call() {
  const router = useRouter();
  const [astrologers, setAstrologers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulating API call to fetch astrologers
    setTimeout(() => {
      setAstrologers([
        {
          id: '1',
          name: 'Eshwar',
          specialty: 'Vedic Astrology',
          experience: '15+ years',
          languages: ['Hindi', 'English'],
          rating: 4.8,
          price: 20,
          online: true,
          image: 'https://9starsguru.com/wp-content/uploads/2025/03/DSC03033-scaled.jpg'
        },
        {
          id: '2',
          name: 'Dr. Priya Verma',
          specialty: 'Tarot Reading',
          experience: '12+ years',
          languages: ['Hindi', 'English', 'Tamil'],
          rating: 4.7,
          price: 25,
          available: true,
          image: 'https://9starsguru.com/wp-content/uploads/2025/03/DSC03026-scaled.jpg'
        },
        {
          id: '3',
          name: 'Pandit Rajesh',
          specialty: 'Numerology',
          experience: '10+ years',
          languages: ['Hindi', 'English', 'Marathi'],
          rating: 4.5,
          price: 15,
          available: false,
          image: 'https://9starsguru.com/wp-content/uploads/2025/03/DSC03040-scaled.jpg'
        },
        {
          id: '4',
          name: 'Maya Desai',
          specialty: 'Palmistry',
          experience: '8+ years',
          languages: ['Hindi', 'English', 'Gujarati'],
          rating: 4.6,
          price: 18,
          available: true,
          image: 'https://9starsguru.com/wp-content/uploads/2025/03/DSC03009-scaled.jpg'
        }
      ]);
      setLoading(false);
    }, 1000);
  }, []);

  const handleCallRequest = (astrologer) => {
    if (!astrologer.available) {
      Alert.alert(
        "Astrologer Unavailable",
        "This astrologer is currently unavailable for calls. Please try again later or choose another astrologer."
      );
      return;
    }
    
    Alert.alert(
      "Confirm Call Consultation",
      `Start a call consultation with ${astrologer.name}? This will cost ₹${astrologer.price}/minute.`,
      [
        {
          text: "Cancel",
          style: "cancel"
        },
        { 
          text: "Pay ₹500", 
          onPress: () => {
            // In a real app, this would open the Razorpay payment gateway
            Alert.alert(
              "Payment Successful",
              "You have successfully paid ₹500 for call consultation. You will be connected to the astrologer now.",
              [
                { 
                  text: "Continue", 
                  onPress: () => {
                    router.push({
                      pathname: '/call/[id]',
                      params: { 
                        id: astrologer.id,
                        name: astrologer.name,
                        price: astrologer.price,
                        image: astrologer.image
                      }
                    });
                  }
                }
              ]
            );
          }
        }
      ]
    );
  };

  const renderAstrologerCard = ({ item }) => {
    return (
      <View style={styles.astrologerCard}>
        <View style={styles.astrologerHeader}>
          <Image 
            source={{ uri: item.image }}
            style={styles.astrologerImage}
          />
          <View style={[
            styles.statusIndicator, 
            { backgroundColor: item.available ? COLORS.success : COLORS.darkGray }
          ]} />
        </View>
        
        <View style={styles.astrologerInfo}>
          <Text style={styles.astrologerName}>{item.name}</Text>
          <Text style={styles.astrologerSpecialty}>{item.specialty}</Text>
          
          <View style={styles.ratingContainer}>
            <Star size={16} color={COLORS.primary} fill={COLORS.primary} />
            <Text style={styles.ratingText}>{item.rating}</Text>
          </View>
          
          <Text style={styles.experienceText}>
            <Clock size={14} color={COLORS.darkGray} /> {item.experience}
          </Text>
          
          <Text style={styles.languagesText}>
            {item.languages.join(' • ')}
          </Text>
          
          <View style={styles.priceContainer}>
            <Text style={styles.priceLabel}>₹{item.price}/min</Text>
            <TouchableOpacity 
              style={[
                styles.callButton,
                !item.available && styles.callButtonDisabled
              ]}
              onPress={() => handleCallRequest(item)}
              disabled={!item.available}
            >
              <PhoneCall size={16} color={COLORS.white} />
              <Text style={styles.callButtonText}>Call Now</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    );
  };

  if (loading) {
    return (
      <View style={[styles.container, styles.centered]}>
        <Text>Loading astrologers...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.infoBox}>
        <Phone size={20} color={COLORS.primary} />
        <Text style={styles.infoText}>
          Call consultations start at ₹500 for 25 minutes. Your wallet balance will be used.
        </Text>
      </View>
      
      <FlatList
        data={astrologers}
        renderItem={renderAstrologerCard}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listContainer}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.lightBackground,
  },
  centered: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.white,
    padding: 16,
    margin: 16,
    borderRadius: 10,
    borderLeftWidth: 4,
    borderLeftColor: COLORS.primary,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  infoText: {
    flex: 1,
    marginLeft: 12,
    color: COLORS.darkGray,
    fontSize: 14,
  },
  listContainer: {
    padding: 16,
    paddingTop: 0,
  },
  astrologerCard: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    marginBottom: 16,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  astrologerHeader: {
    position: 'relative',
  },
  astrologerImage: {
    width: '100%',
    height: 180,
  },
  statusIndicator: {
    position: 'absolute',
    top: 12,
    right: 12,
    width: 12,
    height: 12,
    borderRadius: 6,
    borderWidth: 2,
    borderColor: COLORS.white,
  },
  astrologerInfo: {
    padding: 16,
  },
  astrologerName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.black,
    marginBottom: 4,
  },
  astrologerSpecialty: {
    fontSize: 14,
    color: COLORS.darkGray,
    marginBottom: 8,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  ratingText: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.darkGray,
    marginLeft: 4,
  },
  experienceText: {
    fontSize: 14,
    color: COLORS.darkGray,
    marginBottom: 4,
  },
  languagesText: {
    fontSize: 14,
    color: COLORS.darkGray,
    marginBottom: 12,
  },
  priceContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 8,
  },
  priceLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.primary,
  },
  callButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.primary,
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
  },
  callButtonDisabled: {
    backgroundColor: COLORS.lightGray,
  },
  callButtonText: {
    color: COLORS.white,
    fontWeight: '600',
    marginLeft: 4,
  },
});